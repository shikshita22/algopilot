package com.iiitd.dsavisualizer.algorithms.sorting.insertion;

// InsertionSortData
public class InsertionSortData {
    public int data;
    public int index;
}