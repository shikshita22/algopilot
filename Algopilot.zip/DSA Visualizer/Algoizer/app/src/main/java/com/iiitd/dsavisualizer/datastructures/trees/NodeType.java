package com.iiitd.dsavisualizer.datastructures.trees;

// ENUM Class
// Used by Trees for knowing the type of node
public enum NodeType {
    EMPTY,
    ARROW,
    ELEMENT
}
