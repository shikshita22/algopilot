package com.iiitd.dsavisualizer.algorithms.sorting.selection;

// SelectionSortData
public class SelectionSortData {
    public int data;
    public int index;
}