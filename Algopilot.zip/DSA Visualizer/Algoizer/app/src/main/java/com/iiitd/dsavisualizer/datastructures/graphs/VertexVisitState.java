package com.iiitd.dsavisualizer.datastructures.graphs;

// ENUM Class
// Used by BFS, DFS
public enum VertexVisitState {
    WHITE,
    GRAY,
    BLACK
}