package com.iiitd.dsavisualizer.algorithms.sorting.quick;

// QuickSortData
public class QuickSortData {
    public int data;
    public int index;
}